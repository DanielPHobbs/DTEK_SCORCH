Automated Deploy
Run the deploy.ps1 script as an administrator -- after this you can just do import-module scorch from any PowerShell instance on the machine