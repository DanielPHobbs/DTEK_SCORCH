---
Module Name: PSWinReportingV2
Module Guid: ea2bd8d2-cca1-4dc3-9e1c-ff80b06e8fbe
Download Help Link: {{ Update Download Link }}
Help Version: {{ Please enter version of help manually (X.X.X.X) format }}
Locale: en-US
---

# PSWinReportingV2 Module
## Description
{{ Fill in the Description }}

## PSWinReportingV2 Cmdlets
### [Add-EventsDefinitions](Add-EventsDefinitions.md)
{{ Fill in the Synopsis }}

### [Add-WinTaskScheduledForwarder](Add-WinTaskScheduledForwarder.md)
{{ Fill in the Synopsis }}

### [Find-Events](Find-Events.md)
{{ Fill in the Synopsis }}

### [New-WinSubscriptionTemplates](New-WinSubscriptionTemplates.md)
{{ Fill in the Synopsis }}

### [Remove-WinTaskScheduledForwarder](Remove-WinTaskScheduledForwarder.md)
{{ Fill in the Synopsis }}

### [Start-WinNotifications](Start-WinNotifications.md)
{{ Fill in the Synopsis }}

### [Start-WinReporting](Start-WinReporting.md)
{{ Fill in the Synopsis }}

### [Start-WinSubscriptionService](Start-WinSubscriptionService.md)
{{ Fill in the Synopsis }}

