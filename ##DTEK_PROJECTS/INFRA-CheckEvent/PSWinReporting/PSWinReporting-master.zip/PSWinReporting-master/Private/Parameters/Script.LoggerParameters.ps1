$Script:LoggerParameters = @{
    ShowTime   = $false
    TimeFormat = 'yyyy-MM-dd HH:mm:ss'
}