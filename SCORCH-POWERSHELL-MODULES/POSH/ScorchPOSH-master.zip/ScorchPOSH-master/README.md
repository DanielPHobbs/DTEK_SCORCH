# ScorchPOSH
PowerShell module for System Center Orchestrator (Scorch)
